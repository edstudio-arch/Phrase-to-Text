
import React from 'react';
import { PhotoIcon } from './Icon';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <div className="flex items-center justify-center gap-4">
        <PhotoIcon className="w-10 h-10 text-cyan-400"/>
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-transparent bg-clip-text">
          Phrase to Image
        </h1>
      </div>
      <p className="mt-4 text-lg text-slate-400">
        Transform your words into works of art with the power of AI.
      </p>
    </header>
  );
};

export default Header;
