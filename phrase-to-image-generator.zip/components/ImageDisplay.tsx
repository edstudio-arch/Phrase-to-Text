
import React from 'react';
import Loader from './Loader';
import { ImageIcon, AlertTriangleIcon } from './Icon';

interface ImageDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
  error: string | null;
  prompt: string;
}

const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageUrl, isLoading, error, prompt }) => {
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-400">
          <Loader />
          <p className="text-lg">Generating your masterpiece...</p>
        </div>
      );
    }
    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full gap-4 text-red-400 p-4">
          <AlertTriangleIcon className="w-12 h-12" />
          <p className="text-lg font-semibold">Oops! Something went wrong.</p>
          <p className="text-center text-sm text-red-300">{error}</p>
        </div>
      );
    }
    if (imageUrl) {
      return (
        <img
          src={imageUrl}
          alt={prompt || 'Generated image'}
          className="w-full h-full object-cover rounded-lg transition-opacity duration-500 opacity-0 animate-fade-in"
          onLoad={(e) => e.currentTarget.style.opacity = '1'}
        />
      );
    }
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-500">
        <ImageIcon className="w-16 h-16"/>
        <p className="text-lg text-center">Your generated image will appear here</p>
      </div>
    );
  };

  return (
    <div className="w-full aspect-square bg-slate-800 border-2 border-dashed border-slate-700 rounded-lg flex items-center justify-center overflow-hidden transition-colors duration-300">
      {renderContent()}
    </div>
  );
};

export default ImageDisplay;
